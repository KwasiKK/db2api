<!DOCTYPE html>
<html lang="en">
<head>

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="Assigned Developer should fill this in">
		<meta name="author" content="Kabelo Kwasi Kgwete">

		<title>Assigned Developer should fill this in</title>

		<!-- Bootstrap Core CSS -->
		<link href="{{ asset('/css/bootstrap.min.css') }}" rel="stylesheet">

		<!-- Custom CSS -->
		<link href="{{ asset('/css/application.css') }}" rel="stylesheet">

		<!-- bootstrap-switch CSS -->
		<link href="{{ asset('/css/highlight.css') }}" rel="stylesheet">
		<link href="{{ asset('/css/bootstrap-switch.css') }}" rel="stylesheet">

		<!-- Favicons -->
		<link href="{{ asset('/img/favicon/favicon.png') }}" rel="shortcut icon">
		<link href="{{ asset('/img/favicon/apple-touch-icon-57-precomposed.png') }}" rel="apple-touch-icon">
		<link href="{{ asset('/img/favicon/apple-touch-icon-72-precomposed.png') }}" rel="apple-touch-icon" sizes="72x72">
		<link href="{{ asset('/img/favicon/apple-touch-icon-144-precomposed.png') }}" rel="apple-touch-icon" sizes="114x114">

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
				<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
				<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->

		<!-- Modernizr Scripts -->
		<script src="{{ asset('/js/vendor/modernizr-2.7.1.min.js') }}"></script>

		@yield('head')
</head>
<body	class="index" id="to-top">
		<!-- Side nav -->
		<nav class="side-nav" role="navigation">

			<ul class="nav-side-nav">
				<li><a class="tooltip-side-nav" href="#section-1" title="" data-original-title="Services" data-placement="left"></a></li>
				<li><a class="tooltip-side-nav" href="#section-2" title="" data-original-title="Features" data-placement="left"></a></li>
				<li><a class="tooltip-side-nav" href="#section-3" title="" data-original-title="Subscribe" data-placement="left"></a></li>
				<li><a class="tooltip-side-nav" href="#to-top" title="" data-original-title="Back" data-placement="left"></a></li>
			</ul>

		</nav> <!-- /.side-nav -->

		<div class="feedback"></div>

		@yield('content')

		@yield('modals')

		<!-- Footer -->
		<footer class="footer-section" role="contentinfo">

			<div class="container">

				<div class="row">

					<div class="col-md-4 col-footer">

						<!-- Footer 1 -->
						<section>
							<p>Made with <i class="fa fa-heart"></i> by Kwasi Kgwete.</p>
						</section>

						<!-- AddThis Button -->
						<ul class="addthis_toolbox addthis_default_style">

							<li><a class="addthis_button_facebook_like"></a></li>
							<li><a class="addthis_button_tweet"></a></li>

						</ul> <!-- /.addthis_toolbox -->

					</div> <!-- /.col-md-4 -->

					<div class="col-md-4 col-footer col-padding">

						<!-- Footer 1 -->
						<section class="text-center">
							<p>Be sure to read <a href="#fakelinks">Terms</a> and <a href="#fakelinks">Privacy Policy</a>.</p>
						</section>

						<!-- Social media links -->
						<ul class="social-media-links">

							<li><a class="fa fa-twitter tw" href="#fakelinks"></a></li>
							<li><a class="fa fa-facebook fb" href="#fakelinks"></a></li>
							<li><a class="fa fa-pinterest pn" href="#fakelinks"></a></li>

						</ul> <!-- /.social-media-links -->

					</div> <!-- /.col-md-4 -->

					<div class="col-md-4 col-footer">

						<!-- Footer 1 -->
						<section>
							<p><strong>Marabele Enterprise</strong> <br>Berantah Street, Block 123 <br>South, 12356.</p>
						</section>

					</div> <!-- /.col-md-4 -->

				</div> <!-- /.row -->

			</div> <!-- /.container -->

		</footer> <!-- /.footer-section -->

		@yield('footer')

		<style type="text/css">
				.img-logo{
					border-radius: 0px 55px 91px;
					background-color: aliceblue;
				}
		</style>

		<!-- Scripts -->
		<script src="{{ asset('/js/vendor/jquery-2.1.0.min.js') }}"></script>
		<script src="{{ asset('/js/bootstrap.min.js') }}"></script>
	<script src="{{ asset('/js/jquery.form.js') }}"></script>

	<!-- Plugin JavaScript -->
	<script src="{{ asset('/js/assets/application.js') }}"></script>

	<!-- Plugin JavaScript -->
	<script src="{{ asset('/js/assets/highlight.js') }}"></script>
	<script src="{{ asset('/js/bootstrap-switch.js') }}"></script>
	<script src="{{ asset('/js/main.js') }}"></script>

		@if(isset($welcome_page))

		@else
				<script type="text/javascript">//$(".navbar").addClass("top-nav-collapse");</script>
		@endif

		@yield('scripts')
</body>
</html>

