@extends("app")
@section("content")
<div class="container">

<div class="crud-menu">
		<a href="{{ URL::to('house') }}" class="btn btn-small btn-success">View All house</a>
		<a href="{{ URL::to('house/create') }}" class="btn btn-small btn-success">Create a house</a>
</div>

<h1>Edit house</h1>

{!! Form::model($house, array('method' => 'PATCH', 'action' => ['houseController@update', $house->id])) !!}

@include('house.form', ['submitButtonText' => 'Update'])

{!! Form::close() !!}

@include('errors.list')

</div>
@stop
