	<div class="form-group">
		{!! Form::label('name', 'rooms') !!}
		{!! Form::text('rooms', Input::old('rooms'), array('class' => 'form-control')) !!}
	</div>

	<div class="form-group">
		{!! Form::label('name', 'location') !!}
		{!! Form::text('location', Input::old('location'), array('class' => 'form-control')) !!}
	</div>

	<div class="form-group">
		{!! Form::label('name', 'type') !!}
		{!! Form::text('type', Input::old('type'), array('class' => 'form-control')) !!}
	</div>

	{!! Form::submit($submitButtonText, array('class' => 'btn btn-primary')) !!}

