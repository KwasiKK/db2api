@extends("app")
@section("content")
<div class="container">

<div class="crud-menu">
		<a href="{{ URL::to('house') }}" class="btn btn-small btn-success">View All house</a>
		<a href="{{ URL::to('house/create') }}" class="btn btn-small btn-success">Create a house</a>
</div>

<h1>Showing houses</h1>

<!-- will be used to show any messages -->
@if (Session::has('message'))
	<div class="alert alert-info">{{ Session::get('message') }}</div>
@endif

<table class="table table-striped table-bordered">
	<thead>
		<tr>
			<td>rooms</td>
			<td>location</td>
			<td>type</td>
			<td></td>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>{{ $house->rooms }}</td>
			<td>{{ $house->location }}</td>
			<td>{{ $house->type }}</td>
			<!-- we will also add show, edit, and delete buttons -->
			<td>
				<!-- delete the house (uses the destroy method DESTROY /house/{id} -->
				<!-- we will add this later since its a little more complicated than the first two buttons -->
				{!! Form::open(array('url' => 'house/' . $house->id, 'class' => 'table-btn')) !!}
					{!! Form::hidden('_method', 'DELETE') !!}
					{!! Form::submit('Delete', array('class' => 'btn btn-warning btn-xs')) !!}
				{!! Form::close() !!}

				<!-- edit this house (uses the edit method found at GET /house/{id}/edit -->
				<a class="btn btn-xs btn-info table-btn" href="{{ URL::to('house/' . $house->house_id . '/edit') }}">Edit</a>

			</td>
		</tr>
	</tbody>
</table>

</div>
@stop
