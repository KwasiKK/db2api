@extends("app")
@section("content")
<div class="container">

<div class="crud-menu">
		<a href="{{ URL::to('house') }}" class="btn btn-small btn-success">View All house</a>
		<a href="{{ URL::to('house/create') }}" class="btn btn-small btn-success">Create a house</a>
</div>

<h1>Create a house</h1>

{!! Form::open(array('url' => 'house')) !!}

@include('house.form', ['submitButtonText' => 'Create'])

{!! Form::close() !!}

@include('errors.list')

</div>
@stop
