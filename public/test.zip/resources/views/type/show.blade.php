@extends("app")
@section("content")
<div class="container">

<div class="crud-menu">
		<a href="{{ URL::to('type') }}" class="btn btn-small btn-success">View All type</a>
		<a href="{{ URL::to('type/create') }}" class="btn btn-small btn-success">Create a type</a>
</div>

<h1>Showing types</h1>

<!-- will be used to show any messages -->
@if (Session::has('message'))
	<div class="alert alert-info">{{ Session::get('message') }}</div>
@endif

<table class="table table-striped table-bordered">
	<thead>
		<tr>
			<td>name</td>
			<td>status</td>
			<td>heat</td>
			<td></td>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>{{ $type->name }}</td>
			<td>{{ $type->status }}</td>
			<td>{{ $type->heat }}</td>
			<!-- we will also add show, edit, and delete buttons -->
			<td>
				<!-- delete the type (uses the destroy method DESTROY /type/{id} -->
				<!-- we will add this later since its a little more complicated than the first two buttons -->
				{!! Form::open(array('url' => 'type/' . $type->id, 'class' => 'table-btn')) !!}
					{!! Form::hidden('_method', 'DELETE') !!}
					{!! Form::submit('Delete', array('class' => 'btn btn-warning btn-xs')) !!}
				{!! Form::close() !!}

				<!-- edit this type (uses the edit method found at GET /type/{id}/edit -->
				<a class="btn btn-xs btn-info table-btn" href="{{ URL::to('type/' . $type->type_id . '/edit') }}">Edit</a>

			</td>
		</tr>
	</tbody>
</table>

</div>
@stop
