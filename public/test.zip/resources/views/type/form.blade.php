	<div class="form-group">
		{!! Form::label('name', 'name') !!}
		{!! Form::text('name', Input::old('name'), array('class' => 'form-control')) !!}
	</div>

	<div class="form-group">
		{!! Form::label('name', 'status') !!}
		{!! Form::text('status', Input::old('status'), array('class' => 'form-control')) !!}
	</div>

	<div class="form-group">
		{!! Form::label('name', 'heat') !!}
		{!! Form::text('heat', Input::old('heat'), array('class' => 'form-control')) !!}
	</div>

	{!! Form::submit($submitButtonText, array('class' => 'btn btn-primary')) !!}

