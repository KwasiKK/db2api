@extends("app")
@section("content")
<div class="container">

<div class="crud-menu">
		<a href="{{ URL::to('type') }}" class="btn btn-small btn-success">View All type</a>
		<a href="{{ URL::to('type/create') }}" class="btn btn-small btn-success">Create a type</a>
</div>

<h1>Create a type</h1>

{!! Form::open(array('url' => 'type')) !!}

@include('type.form', ['submitButtonText' => 'Create'])

{!! Form::close() !!}

@include('errors.list')

</div>
@stop
