@extends("app")
@section("content")
<div class="container">

<div class="crud-menu">
		<a href="{{ URL::to('type') }}" class="btn btn-small btn-success">View All type</a>
		<a href="{{ URL::to('type/create') }}" class="btn btn-small btn-success">Create a type</a>
</div>

<h1>Edit type</h1>

{!! Form::model($type, array('method' => 'PATCH', 'action' => ['typeController@update', $type->id])) !!}

@include('type.form', ['submitButtonText' => 'Update'])

{!! Form::close() !!}

@include('errors.list')

</div>
@stop
