@extends("app")
@section("content")
<div class="container">

<div class="crud-menu">
		<a href="{{ URL::to('type') }}" class="btn btn-small btn-success">View All type</a>
		<a href="{{ URL::to('type/create') }}" class="btn btn-small btn-success">Create a type</a>
</div>

<h1>All the types</h1>

<!-- will be used to show any messages -->
@if (Session::has('message'))
	<div class="alert alert-info">{{ Session::get('message') }}</div>
@endif

<table class="table table-striped table-bordered data-table">
	<thead>
		<tr>
			<td>name</td>
			<td>status</td>
			<td>heat</td>
			<td></td>
		</tr>
	</thead>
	<tbody>
	<?php foreach($type as $key => $value){ ?>
		<tr>
			<td><?php echo $value->name; ?></td>
			<td><?php echo $value->status; ?></td>
			<td><?php echo $value->heat; ?></td>
			<!-- we will also add show, edit, and delete buttons -->
			<td>
				<!-- delete the type (uses the destroy method DESTROY /type/{id} -->
				<!-- we will add this later since its a little more complicated than the first two buttons -->
				{!! Form::open(array('url' => 'type/' . $value->id, 'class' => 'table-btn')) !!}
					{!! Form::hidden('_method', 'DELETE') !!}
					{!! Form::submit('Delete', array('class' => 'btn btn-xs btn-warning')) !!}
				{!! Form::close() !!}

				<!-- show the type (uses the show method found at GET /type/{id} -->
				<a class="btn btn-xs btn-success table-btn" href="{{ URL::to('type/' . $value->id) }}" >Show</a>

				<!-- edit this type (uses the edit method found at GET /type/{id}/edit -->
				<a class="btn btn-xs btn-info table-btn" href="{{ URL::to('type/' . $value->id . '/edit') }}">Edit</a>

			</td>
		</tr>
	<?php } ?>
	</tbody>
</table>

</div>
@stop
@section("scripts")
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.8/css/dataTables.bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.0.1/css/buttons.bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/colreorder/1.2.0/css/colReorder.bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/1.0.7/css/responsive.bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/scroller/1.3.0/css/scroller.bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/select/1.0.0/css/select.bootstrap.min.css"/>

<script type="text/javascript" src="https://code.jquery.com/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
<script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.8/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.8/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.0.1/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.0.1/js/buttons.bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.0.1/js/buttons.colVis.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.0.1/js/buttons.flash.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.0.1/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.0.1/js/buttons.print.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/colreorder/1.2.0/js/dataTables.colReorder.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/1.0.7/js/dataTables.responsive.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/scroller/1.3.0/js/dataTables.scroller.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/select/1.0.0/js/dataTables.select.min.js"></script>

<script>
$(document).ready(function() {
	$('.data-table').DataTable({
		lengthMenu: [[10, 25, 50, -1], [10, 25, 50, "All"]],
		dom: 'Bfrtip',
		buttons: [
			'colvis',
			'excel'
		]
	});
});
</script>

@stop
