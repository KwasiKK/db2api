@extends("main")
@section("content")
<div class="container">

	@include('errors.list')

	<form method="POST" action="/auth/login">	{!! csrf_field() !!}
	<h2 class="text-center  wowload fadeInUp no-margin-btm">Sign In</h2>
	<div class="row wowload fadeInLeftBig">
		<div id="signupbox" class="mainbox col-md-5 col-md-offset-4 col-sm-8 col-sm-offset-2 col-lg-4 col-lg-offset-4">
			<div class="panel panel-info">
				<div class="panel-body" >
					<div id="signupform" class="form-horizontal" role="form">
						<div class="form-group">
							<label for="email" class="col-md-3 control-label">Email</label>
							<div class="col-md-9">
								<input type="text" class="form-control" required value="{{ old('email') }}" name="email" placeholder="Email" >
							</div>
						</div>
						<div class="form-group">
							<label for="email" class="col-md-3 control-label">Password</label>
							<div class="col-md-9">
								<input type="text" class="form-control" required name="password" placeholder="Password" >
							</div>
						</div>
						<div class="form-group">
							<label for="email" class="col-md-3 control-label">Remember Me</label>
							<div class="col-md-9">
								<input type="checkbox" required name="remember" >
							</div>
						</div>
						<div>
							<button type="submit">Login</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	</form>
	</div>
</section>
@endsection
