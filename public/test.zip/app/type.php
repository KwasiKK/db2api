<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class type extends Model
{
	public $table = 'type'; 
	protected $fillable = [ 
          'name', 
          'status', 
          'heat' 
      ]; 
    //
}
