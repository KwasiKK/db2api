<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class typeController extends Controller
{
use growth__zZjCr\type;
use View;
use Form;
use Validator;
use Input;
use Session;
use Redirect;

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
		// get all the types 
		$type = type::all();

		// load the view and pass the types 
		return View::make('type.index')->with('type', $type);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
		// load the create form (app/views/type/create.blade.php) 
		return View::make('type.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
		// validate input 
		$rules = array(
			'name' => 'required', 
			'status' => 'required', 
			'heat' => 'required' 
		); 
		$validator = Validator::make(Input::all(), $rules);

		// process the validator
		if($validator->fails()){
			return Redirect::to('type/create')
				->withErrors($validator)
				->withInput(Input::all());
		} else {
			// store the data 
			$type = new type; 
			$type->name = Input::get('name');
			$type->status = Input::get('status');
			$type->heat = Input::get('heat');
			$type->save();

			// redirect
			Session::flash('message', 'Successfully created type!');
			return Redirect::to('type');
		}
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
		// get one type 
		$type = type::find($id);

		// show the view and pass the type to it 
		return View::make('type.show')->with('type', $type);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
		// get one type 
		$type = type::find($id);

		// show the view and pass the type to it 
		return View::make('type.edit')->with('type', $type);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
		// validate input 
		$rules = array(
			'name' => 'required', 
			'status' => 'required', 
			'heat' => 'required' 
		); 
		$validator = Validator::make(Input::all(), $rules);

		// process the validator
		if($validator->fails()){
			return Redirect::to('type/'.$id.'/edit')
				->withErrors($validator)
				->withInput(Input::all());
		} else {
			// store the data 
			$type = type::find($id); 
			$type->name = Input::get('name');
			$type->status = Input::get('status');
			$type->heat = Input::get('heat');
			$type->save();

			// redirect
			Session::flash('message', 'Successfully updated type!');
			return Redirect::to('type');
		}
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
		// delete one type 
		$type = type::find($id);

		$type->delete();

		// redirect
		Session::flash('message', 'Successfully deleted the type!');
		return Redirect::to('type');
    }
}
