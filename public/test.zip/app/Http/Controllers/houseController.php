<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class houseController extends Controller
{
use growth__zZjCr\house;
use View;
use Form;
use Validator;
use Input;
use Session;
use Redirect;

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
		// get all the houses 
		$house = house::all();

		// load the view and pass the houses 
		return View::make('house.index')->with('house', $house);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
		// load the create form (app/views/house/create.blade.php) 
		return View::make('house.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
		// validate input 
		$rules = array(
			'rooms' => 'required', 
			'location' => 'required', 
			'type' => 'required' 
		); 
		$validator = Validator::make(Input::all(), $rules);

		// process the validator
		if($validator->fails()){
			return Redirect::to('house/create')
				->withErrors($validator)
				->withInput(Input::all());
		} else {
			// store the data 
			$house = new house; 
			$house->rooms = Input::get('rooms');
			$house->location = Input::get('location');
			$house->type = Input::get('type');
			$house->save();

			// redirect
			Session::flash('message', 'Successfully created house!');
			return Redirect::to('house');
		}
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
		// get one house 
		$house = house::find($id);

		// show the view and pass the house to it 
		return View::make('house.show')->with('house', $house);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
		// get one house 
		$house = house::find($id);

		// show the view and pass the house to it 
		return View::make('house.edit')->with('house', $house);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
		// validate input 
		$rules = array(
			'rooms' => 'required', 
			'location' => 'required', 
			'type' => 'required' 
		); 
		$validator = Validator::make(Input::all(), $rules);

		// process the validator
		if($validator->fails()){
			return Redirect::to('house/'.$id.'/edit')
				->withErrors($validator)
				->withInput(Input::all());
		} else {
			// store the data 
			$house = house::find($id); 
			$house->rooms = Input::get('rooms');
			$house->location = Input::get('location');
			$house->type = Input::get('type');
			$house->save();

			// redirect
			Session::flash('message', 'Successfully updated house!');
			return Redirect::to('house');
		}
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
		// delete one house 
		$house = house::find($id);

		$house->delete();

		// redirect
		Session::flash('message', 'Successfully deleted the house!');
		return Redirect::to('house');
    }
}
